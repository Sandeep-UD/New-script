# Archive/Unarchive GitHub Repositories

These scripts automate archiving and unarchiving GitHub repositories in bulk from a CSV file.

## Prerequisites

- Python 3.x
- Required packages: `requests`, `python-dotenv`

Install dependencies:
```bash
pip install requests python-dotenv
```

## Setup

1. Create a `.env` file with the following variables:
```
GH_TOKEN=your_github_personal_access_token
GH_ORG=your_organization_name
```

2. Create a CSV file named `repositories.csv` with the following format:
```csv
repo_name
my-repo-1
my-repo-2
my-repo-3
```

## CSV Format

| Column | Description |
|--------|-------------|
| `repo_name` | Repository name (without org prefix) |

## Usage

### Archive Repositories
Archives repositories (makes them read-only):
```bash
python archive_repos.py
```

### Unarchive Repositories
Unarchives repositories (makes them writable again):
```bash
python unarchive_repos.py
```

## Features

### Archive Script
- ✅ Archives repositories from CSV list
- ✅ Makes repositories read-only
- ✅ Detailed logging to `archive_repos.log`
- ✅ Error handling and status reporting

### Unarchive Script
- ✅ Unarchives repositories from CSV list
- ✅ Restores write access to repositories
- ✅ Automatic rate limit handling
- ✅ Detailed logging to `unarchive_repos.log`
- ✅ Network error handling

## Token Permissions

The GitHub Personal Access Token must have:
- `repo` scope - Full repository access including archive/unarchive permissions

## Important Notes

### Archived Repositories
- **Read-only**: Cannot push code, open issues, or create pull requests
- **Visible**: Still visible and can be cloned/forked
- **Reversible**: Can be unarchived at any time
- **Settings locked**: Repository settings cannot be changed while archived

### Use Cases
- **Archiving**: Preserve old/completed projects, deprecated repositories, or historical codebases
- **Unarchiving**: Restore repositories for maintenance, bug fixes, or renewed development

## Logging

Both scripts generate detailed log files:
- `archive_repos.log` - Archive operations log
- `unarchive_repos.log` - Unarchive operations log

Logs include:
- Timestamps for all operations
- Success/failure status for each repository
- Error messages and HTTP status codes
- API response details

## Example Output

### Archive Script
```
Archiving repository: my-repo-1
Repository 'my-repo-1' has been archived successfully.
Archiving repository: my-repo-2
Repository 'my-repo-2' has been archived successfully.
```

### Unarchive Script
```
Unarchiving repository: my-repo-1
Repository 'my-repo-1' has been unarchived successfully.
Unarchiving repository: my-repo-2
Repository 'my-repo-2' has been unarchived successfully.
Rate limit exceeded. Waiting for 45 seconds...
```

## Troubleshooting

### Repository Not Found
- Verify repository name is correct (case-sensitive)
- Ensure repository exists in the specified organization
- Check token has access to the repository

### Permission Denied
- Verify token has `repo` scope
- Ensure you have admin access to the repositories
- Check token hasn't expired

### Rate Limiting
- Unarchive script automatically handles rate limits
- Script will pause and wait when limits are reached
- Archive script processes requests sequentially
- Consider adding delays between requests for large batches

### CSV Format Errors
- Ensure CSV has `repo_name` column header
- Remove any empty rows
- Check for special characters in repository names
- Verify file encoding is UTF-8

## Batch Processing Tips

For large numbers of repositories:
1. Test with a small subset first
2. Monitor log files for errors
3. Rate limits reset hourly (5000 requests/hour for authenticated users)
4. Consider running during off-peak hours
5. Keep backups of your CSV file

## API Rate Limits

GitHub API limits:
- 5,000 requests per hour for authenticated users
- Unarchive script includes automatic rate limit detection
- Both scripts log rate limit information
