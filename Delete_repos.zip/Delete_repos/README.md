# Delete GitHub Repositories

This script permanently deletes GitHub repositories in bulk from an organization based on a CSV file.

## ⚠️ WARNING

**This script permanently deletes repositories. This action cannot be undone. Use with extreme caution.**

## Prerequisites

- Python 3.x
- Required packages: `requests`, `python-dotenv`

Install dependencies:
```bash
pip install requests python-dotenv
```

## Setup

1. Create a `.env` file with the following variables:
```
GITHUB_ORG=your_organization_name
GITHUB_PAT=your_github_personal_access_token
```

2. Create a CSV file named `repos.csv` with the following format:
```csv
repo_name
my-repo-1
my-repo-2
old-project
```

## CSV Format

| Column | Description |
|--------|-------------|
| `repo_name` | Repository name to delete (without org prefix) |

## Usage

Run the script:
```bash
python repo-deletion.py
```

The script will:
1. Validate your credentials and organization access
2. Read repository names from `repos.csv`
3. Display a list of repositories to be deleted
4. Ask for confirmation (you must type `DELETE` to proceed)
5. Delete each repository and show progress
6. Display a summary of results

## Features

- ✅ Validates GitHub credentials before deletion
- ✅ Confirms organization access
- ✅ Requires explicit confirmation (type `DELETE`)
- ✅ Checks if repositories exist before attempting deletion
- ✅ Handles rate limiting with automatic delays
- ✅ Detailed progress reporting
- ✅ Comprehensive error handling
- ✅ Summary statistics after completion

## Token Permissions

The GitHub Personal Access Token must have:
- `delete_repo` scope - Required to delete repositories
- `repo` scope - Full repository access

**Note**: Token must have admin access to repositories being deleted.

## Safety Features

### Confirmation Required
- Script displays all repositories to be deleted
- User must type `DELETE` (case-sensitive) to proceed
- Can be cancelled with Ctrl+C at any time

### Validation Checks
- Validates credentials before proceeding
- Verifies organization access
- Checks if each repository exists before deletion
- Provides detailed error messages

## Example Output

```
🚀 GitHub Repository Deletion Script
==================================================
✓ Authenticated as: john-doe
✓ Organization access confirmed: my-org
✓ Found 3 repositories to process

⚠️  WARNING: This will permanently delete 3 repositories from 'my-org'
Repositories to be deleted:
  - old-project
  - deprecated-app
  - test-repo

Are you sure you want to delete these repositories? Type 'DELETE' to confirm: DELETE

🚀 Starting deletion process...

[1/3] Processing: old-project
✅ Successfully deleted repository: old-project

[2/3] Processing: deprecated-app
✅ Successfully deleted repository: deprecated-app

[3/3] Processing: test-repo
⚠️  Repository 'test-repo' not found in organization 'my-org'

📊 Deletion Summary:
✅ Successfully deleted: 2
❌ Failed to delete: 1
📊 Total processed: 3
```

## Important Notes

### Permanent Action
- **Deletion is permanent and cannot be undone**
- All code, issues, pull requests, and wiki content will be deleted
- Repository name becomes available for reuse immediately
- No GitHub recycle bin or recovery mechanism

### Best Practices
1. **Backup first**: Clone repositories before deletion
2. **Archive instead**: Consider archiving repos instead of deleting
3. **Test with non-critical repos**: Verify script works as expected
4. **Double-check CSV**: Review repository list carefully
5. **Use version control**: Keep your CSV file under version control

### Before Deletion
- [ ] Backup important code and data
- [ ] Notify team members
- [ ] Document why repositories are being deleted
- [ ] Consider archiving instead of deletion
- [ ] Verify repository names are correct

## Troubleshooting

### Permission Denied
- Ensure token has `delete_repo` scope
- Verify you have admin access to repositories
- Check organization permissions and policies

### Repository Not Found
- Verify repository name is correct (case-sensitive)
- Ensure repository exists in the specified organization
- Check for typos in CSV file

### Authentication Failed
- Verify `GITHUB_PAT` is correct and not expired
- Ensure token has required scopes
- Check organization name in `.env` file

### Network Errors
- Check internet connection
- Verify GitHub API is accessible
- Script includes automatic retry delays

## CSV File Tips

- Remove empty rows
- Check for trailing spaces in repository names
- Use UTF-8 encoding
- Keep a backup of the CSV file
- Test with a single repository first

## Alternative: Archive Instead

Consider using the archive script instead if you want to:
- Preserve repository history
- Make repositories read-only
- Keep them visible but inactive
- Retain the option to restore later

See `../Archive_repos/README.md` for archiving repositories.

## Rate Limiting

- Script includes 1-second delay between deletions
- GitHub API limit: 5,000 requests/hour
- For large batches, consider running in multiple sessions
- Monitor for rate limit messages

## Exit Codes

- `0` - Success
- `1` - Error occurred or operation cancelled

## Support

For issues or questions:
- Check GitHub API status: https://www.githubstatus.com/
- Review GitHub API documentation
- Verify token permissions and organization access
