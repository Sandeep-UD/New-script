#!/usr/bin/env python3
"""
GitHub Repository Deletion Script

This script deletes repositories from a GitHub organization.
Repository names are read from repos.csv file.
GitHub organization and PAT are read from .env file.

Requirements:
- requests library: pip install requests
- python-dotenv library: pip install python-dotenv
- A .env file with GITHUB_ORG and GITHUB_PAT variables
- A repos.csv file with repo_name column

Usage:
    python repo-deletion.py
"""

import csv
import os
import sys
import requests
from dotenv import load_dotenv
import time


class GitHubRepoDeleter:
    def __init__(self):
        """Initialize the GitHub repository deleter."""
        # Load environment variables from .env file
        load_dotenv()
        
        self.github_org = os.getenv('GITHUB_ORG')
        self.github_pat = os.getenv('GITHUB_PAT')
        
        # Validate required environment variables
        if not self.github_org:
            raise ValueError("GITHUB_ORG environment variable is required")
        if not self.github_pat:
            raise ValueError("GITHUB_PAT environment variable is required")
        
        # Set up API headers
        self.headers = {
            'Authorization': f'token {self.github_pat}',
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'GitHub-Repo-Deleter'
        }
        
        # GitHub API base URL
        self.base_url = 'https://api.github.com'
    
    def validate_credentials(self):
        """Validate GitHub credentials and organization access."""
        try:
            # Test API access
            response = requests.get(
                f'{self.base_url}/user',
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 401:
                raise ValueError("Invalid GitHub Personal Access Token")
            elif response.status_code != 200:
                raise ValueError(f"GitHub API error: {response.status_code}")
            
            user_data = response.json()
            print(f"✓ Authenticated as: {user_data.get('login', 'Unknown')}")
            
            # Test organization access
            org_response = requests.get(
                f'{self.base_url}/orgs/{self.github_org}',
                headers=self.headers,
                timeout=10
            )
            
            if org_response.status_code == 404:
                raise ValueError(f"Organization '{self.github_org}' not found or no access")
            elif org_response.status_code != 200:
                raise ValueError(f"Organization API error: {org_response.status_code}")
            
            print(f"✓ Organization access confirmed: {self.github_org}")
            return True
            
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Network error: {e}")
    
    def read_repos_from_csv(self, csv_file='repos.csv'):
        """Read repository names from CSV file."""
        if not os.path.exists(csv_file):
            raise FileNotFoundError(f"CSV file '{csv_file}' not found")
        
        repos = []
        try:
            with open(csv_file, 'r', newline='', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                
                if 'repo_name' not in reader.fieldnames:
                    raise ValueError("CSV file must contain 'repo_name' column")
                
                for row in reader:
                    repo_name = row['repo_name'].strip()
                    if repo_name:  # Skip empty rows
                        repos.append(repo_name)
        
        except Exception as e:
            raise ValueError(f"Error reading CSV file: {e}")
        
        if not repos:
            raise ValueError("No repositories found in CSV file")
        
        print(f"✓ Found {len(repos)} repositories to process")
        return repos
    
    def check_repo_exists(self, repo_name):
        """Check if repository exists in the organization."""
        try:
            response = requests.get(
                f'{self.base_url}/repos/{self.github_org}/{repo_name}',
                headers=self.headers,
                timeout=10
            )
            return response.status_code == 200
        except requests.exceptions.RequestException:
            return False
    
    def delete_repository(self, repo_name):
        """Delete a repository from the organization."""
        try:
            # First check if repo exists
            if not self.check_repo_exists(repo_name):
                print(f"⚠️  Repository '{repo_name}' not found in organization '{self.github_org}'")
                return False
            
            # Delete the repository
            response = requests.delete(
                f'{self.base_url}/repos/{self.github_org}/{repo_name}',
                headers=self.headers,
                timeout=30
            )
            
            if response.status_code == 204:
                print(f"✅ Successfully deleted repository: {repo_name}")
                return True
            elif response.status_code == 403:
                print(f"❌ Permission denied to delete repository: {repo_name}")
                return False
            elif response.status_code == 404:
                print(f"⚠️  Repository '{repo_name}' not found")
                return False
            else:
                print(f"❌ Failed to delete repository '{repo_name}': HTTP {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error details: {error_data.get('message', 'Unknown error')}")
                except:
                    pass
                return False
                
        except requests.exceptions.RequestException as e:
            print(f"❌ Network error deleting repository '{repo_name}': {e}")
            return False
    
    def delete_repositories(self, csv_file='repos.csv', confirm=True):
        """Delete all repositories listed in the CSV file."""
        try:
            # Validate credentials and organization access
            self.validate_credentials()
            
            # Read repositories from CSV
            repos = self.read_repos_from_csv(csv_file)
            
            # Confirmation prompt
            if confirm:
                print(f"\n⚠️  WARNING: This will permanently delete {len(repos)} repositories from '{self.github_org}'")
                print("Repositories to be deleted:")
                for repo in repos:
                    print(f"  - {repo}")
                
                confirm_input = input(f"\nAre you sure you want to delete these repositories? Type 'DELETE' to confirm: ")
                if confirm_input != 'DELETE':
                    print("❌ Operation cancelled")
                    return
            
            # Delete repositories
            print(f"\n🚀 Starting deletion process...")
            success_count = 0
            failed_count = 0
            
            for i, repo_name in enumerate(repos, 1):
                print(f"\n[{i}/{len(repos)}] Processing: {repo_name}")
                
                if self.delete_repository(repo_name):
                    success_count += 1
                else:
                    failed_count += 1
                
                # Add a small delay between deletions to avoid rate limiting
                if i < len(repos):
                    time.sleep(1)
            
            # Summary
            print(f"\n📊 Deletion Summary:")
            print(f"✅ Successfully deleted: {success_count}")
            print(f"❌ Failed to delete: {failed_count}")
            print(f"📊 Total processed: {len(repos)}")
            
        except Exception as e:
            print(f"❌ Error: {e}")
            sys.exit(1)


def main():
    """Main function."""
    print("🚀 GitHub Repository Deletion Script")
    print("="*50)
    
    try:
        deleter = GitHubRepoDeleter()
        deleter.delete_repositories()
        
    except KeyboardInterrupt:
        print("\n❌ Operation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()